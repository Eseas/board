package com.fastcampus.ch4.sevice;

import org.springframework.stereotype.Service;

@Service
public class BoardService {
	
}
